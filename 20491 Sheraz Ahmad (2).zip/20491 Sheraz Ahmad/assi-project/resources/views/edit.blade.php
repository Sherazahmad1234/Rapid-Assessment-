<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta fullname="viewport" content="width=device-width, initial-scale=1.0">
    @section('title', 'Edit')
</head>
<body>
    @extends('includes.header')

    @section('content')
    <div class="row">
        <div  class="col-md-12">
            <br>
            <h3>Employees Messages Edit </h3>
            <br>
            <form action = "/edit/<?php echo $employees[0]->id; ?>" method = "post">
                <input type = "hidden" fullname = "_token" value = "<?php echo csrf_token(); ?>">
            
                <table>
                    <tr>
                    <td>Name</td>
                    <td>
                        <input type = 'text' fullname = 'fullname' 
                            value = '<?php echo$employees[0]->fullname; ?>'/>
                    </td>
                    <td>Email</td>
                    <td>
                        <input type = 'text' fullname = 'email' 
                            value = '<?php echo$employees[0]->email; ?>'/>
                    </td>
                    <td>Mobile</td>
                    <td>
                        <input type = 'text' fullname = 'mobile' 
                            value = '<?php echo$employees[0]->mobile; ?>'/>
                    </td>
                    <td>Message</td>
                    <td>
                        <input type = 'text' fullname = 'message' 
                            value = '<?php echo$employees[0]->message; ?>'/>
                    </td>
                    </tr>
                    <tr>
                    <td colspan = '2'>
                        <input type = 'submit' value = "Update" />
                    </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
    @endsection
</body>
</html>