<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use App\Models\Employee;
class UpdateController extends Controller
{
    public function index() {
        $employees = DB::select('select * from employees');
        return view('contactmessages',['employees'=>$employees]);
     }
     public function show($id) {
        $employees = DB::select('select * from employees where id = ?',[$id]);
        return view('edit',['employees'=>$employees]);
     }
     public function edit(Request $request,$id) {
        $fullname = $request->input('fullname');
        $email = $request->input('email');
        $mobile = $request->input('mobile');
        $message = $request->input('message');
        DB::update('update employees set fullname = ? where id = ?',[$fullname,$id]);
        DB::update('update employees set email = ? where id = ?',[$email,$id]);
        DB::update('update employees set phone = ? where id = ?',[$phone,$id]);
        DB::update('update employees set message = ? where id = ?',[$message,$id]);
        echo "Record updated successfully.<br/>";
        echo '<a href = "/edit">Click Here</a> to go back.';
        $employees = DB::find($id);
     }

}
