<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use App\Models\Employee;
class delController extends Controller
{
    
        public function index(){
            $row = DB::select('select * from employees');
            return view('stud_delete_view',['row$row'=>$row]);
            }
            public function destroy($id) {
            DB::delete('delete from employees where id = ?',[$id]);
            echo "Record deleted successfully.";
            
            echo '<a href = "/contactmessages">Click Here</a> to go back.';
            }
        
}
